<?php

?>

<nav class="navbar navbar-light bg-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <img src="https://www.101domain.com/images/flags/large/SITE.png" alt="" width="30" height="24" class="d-inline-block align-text-top">
<?php
    echo "
            <p>
            <button type='button' class='btn btn-outline-primary' disabled>Register</button>
            <a id='loginButton' class='btn btn-outline-success'>Login</a>
            </p>
        ";
?>
        </a>
    </div>
</nav>
<?php

?>